 <?php
 session_start(); //Ganz wichtig

$vers= intval($_SESSION['versnr']);
$VName = $_GET['VName'];
$NName = $_GET['NName'];
$GebDatum = $_GET['GebDatum'];
$Ort = $_GET['Ort'];
$Strasse = $_GET['Strasse'];
$TelNr = $_GET['TelNr'];
$Anam = $_GET['Anam'];
$Symp= $_GET['Symp'];
$Diag = $_GET['Diag'];
$Thrp= $_GET['Thrp'];
$Arzt = $_GET['Arzt'];



$servername = "localhost";
$username = "ich";
$password = "ich";
$dbname = "akte";

// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);
// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

$sql = "INSERT INTO Patient VALUES(".$vers.",'".$VName."','".$NName."','".$GebDatum."','".$Ort."','".$Strasse."','".$TelNr."')";
$statement = $conn->prepare($sql);
if(!$statement->execute()) {
  echo "Query fehlgeschlagen: ".$statement->error;
  exit;
}

$sql = "INSERT INTO Patientenakte VALUES(".$vers.",'".$Anam."')";
$statement = $conn->prepare($sql);
if(!$statement->execute()) {
  echo "Query fehlgeschlagen: ".$statement->error;
  exit;
}

$sql = "INSERT INTO Behandlung(Symptome,Diagnose,Therapie) VALUES('".$Symp."','".$Diag."','".$Thrp."')";
$statement = $conn->prepare($sql);
if(!$statement->execute()) {
  echo "Query fehlgeschlagen: ".$statement->error;
  exit;
}

$new_id = $statement->insert_id;

$sql = "INSERT INTO PatientenBehandlung VALUES(".$new_id.",".$vers.")";
$statement = $conn->prepare($sql);
if(!$statement->execute()) {
  echo "Query fehlgeschlagen: ".$statement->error;
  exit;
}





echo 1;



$conn->close();
?>
